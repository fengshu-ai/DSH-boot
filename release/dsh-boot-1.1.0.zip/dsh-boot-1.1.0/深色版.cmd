@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0switch-skin.ps1" -Mode dark
timeout /t 2 >nul
