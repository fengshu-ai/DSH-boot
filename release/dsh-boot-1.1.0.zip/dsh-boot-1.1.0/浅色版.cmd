@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0switch-skin.ps1" -Mode light
timeout /t 2 >nul
