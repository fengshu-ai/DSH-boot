param([ValidateSet('auto', 'dark', 'light')][string]$Mode = 'auto')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $root "skins\$Mode"
$dst = Join-Path $root "dsh-boot"
if (-not (Test-Path $src)) { throw "missing version dir: $src" }
Copy-Item (Join-Path $src 'client.js') (Join-Path $dst 'client.js') -Force
Copy-Item (Join-Path $src 'index.js') (Join-Path $dst 'index.js') -Force
$size = (Get-Item (Join-Path $dst 'client.js')).Length
Write-Host ("switched to {0} version (client.js {1} bytes). DSH hot-reloads; press Ctrl+R if not." -f $Mode, $size)
