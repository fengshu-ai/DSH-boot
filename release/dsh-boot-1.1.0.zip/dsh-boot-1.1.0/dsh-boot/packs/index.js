/**
 * 皮肤包集合：按主题 id 取对应的那一个。
 *
 * 包本身是纯数据（`dark.json` / `light.json`）：
 * 颜色、雪景薄幕、视频滤镜、侧栏配色，以及只属于该主题的 CSS。
 *
 * 构建时（`src/patch.cjs`）会把这些 JSON 直接内联进 client.js，
 * 运行中的皮肤按当前主题 `pick(theme)` 取包套用；这里同样导出给 Node 侧用。
 */

import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const dark = require('./dark.json')
const light = require('./light.json')

/** theme: 'dark' | 'light'；其它值返回 null，由调用方自己决定回退 */
export function pick(theme) {
  if (theme === 'dark') return dark
  if (theme === 'light') return light
  return null
}

export const packs = { dark, light }
export default packs
